import os
import logging
import random
from telebot import TeleBot, types
from openai import OpenAI
import base64
from utils.keyboards import main_menu

logger = logging.getLogger(__name__)

class MealAnalysisHandler:
    def __init__(self, bot: TeleBot, db_manager):
        self.bot = bot
        self.db_manager = db_manager
        try:
            self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            logger.info("OpenAI client successfully initialized")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            raise

        # Коллекция провокационных фраз для разнообразия
        self.spicy_intros = [
            "Ну что, раздеваем твою тарелку?",
            "Время обнажить кулинарную правду!",
            "Голая правда о твоей еде incoming...",
            "Сейчас узнаем, что прячется под соусом!",
            "Внимание, будет горячо... и не только от блюда!"
        ]

        self.calorie_comments = [
            "Калории не прячутся, детка!",
            "Честно? Эта порция - целый роман с последствиями.",
            "Твоя тарелка врёт, я вижу насквозь!",
            "Осторожно, углеводы раздеваются!",
            "Калорийность? Считай, как интимные encounter'ы!"
        ]

    def encode_image(self, image_path):
        """Кодирование изображения в base64"""
        try:
            with open(image_path, "rb") as image_file:
                return base64.b64encode(image_file.read()).decode('utf-8')
        except Exception as e:
            logger.error(f"Ошибка при кодировании изображения: {e}")
            raise

    def handle_start_analysis(self, message):
        """Начало анализа блюда с новым характером"""
        try:
            free_gens, paid_gens = self.db_manager.check_user_generations(message.from_user.id)
            
            if free_gens + paid_gens <= 0:
                self.bot.send_message(
                    message.chat.id,
                    "⚠️ Упс, твои бесплатные свидания с едой закончились. Пополни баланс, красавчик! 💸",
                    reply_markup=main_menu()
                )
                return

            self.bot.send_message(
                message.chat.id,
                "Готов узнать всю правду о своей тарелке? Присылай фото – я не боюсь никаких кулинарных тайн! 🍽️",
                reply_markup=types.ReplyKeyboardRemove()
            )
        except Exception as e:
            logger.error(f"Ошибка при отправке стартового сообщения: {e}")
            self.bot.send_message(
                message.chat.id,
                "Произошла интригующая ошибка. Попробуй соблазнить меня фото еще раз 😉",
                reply_markup=main_menu()
            )

    def handle_photo(self, message):
        """Обработка полученного фото с новым стилем"""
        try:
            free_gens, paid_gens = self.db_manager.check_user_generations(message.from_user.id)
            
            if free_gens + paid_gens <= 0:
                self.bot.send_message(
                    message.chat.id,
                    "⚠️ Твои бесплатные свидания с едой окончены. Пополни баланс, красавчик! 💸",
                    reply_markup=main_menu()
                )
                return

            processing_msg = self.bot.send_message(
                message.chat.id,
                "Раздеваю твою тарелку... Анализирую со страстью к деталям! 🔍"
            )

            file_info = self.bot.get_file(message.photo[-1].file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            os.makedirs("temp", exist_ok=True)
            file_path = f"temp/{message.photo[-1].file_id}.jpg"
            
            try:
                with open(file_path, "wb") as file:
                    file.write(downloaded_file)

                base64_image = self.encode_image(file_path)
            finally:
                if os.path.exists(file_path):
                    os.remove(file_path)

            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": f"{random.choice(self.spicy_intros)}\n\n"
                        "Ты эксперт по питанию с острым языком в стиле FoodNudes. "
                        "Твоя задача - провести максимально честный и дерзкий анализ блюда:\n\n"
                        "🔥 Правила:\n"
                        "1. Определи ингредиенты с язвительным комментарием\n"
                        "2. Укажи калорийность с provокационным намёком\n"
                        "3. Оцени пищевую ценность с легким флиртом\n"
                        "4. Дай совет по употреблению в стиле злого диетолога\n\n"
                        f"{random.choice(self.calorie_comments)}"
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Детально и дерзко опиши это блюдо"},
                            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                        ]
                    }
                ],
                max_tokens=300  # Ограничиваем длину ответа
            )

            self.bot.delete_message(message.chat.id, processing_msg.message_id)

            generations_left = self.db_manager.use_generation(message.from_user.id)
            logger.info(f"Остаток генераций: {generations_left}")

            analysis_result = response.choices[0].message.content

            # Добавляем финальный провокационный аккорд
            final_message = f"{analysis_result}\n\n" \
                            f"🔥 {random.choice(self.calorie_comments)}\n\n" \
                            f"ℹ️ Осталось бесплатных свиданий с едой: {generations_left[0]}\n" \
                            f"ℹ️ Оплаченных анализов: {generations_left[1]}"

            self.bot.send_message(
                message.chat.id,
                final_message,
                reply_markup=main_menu(),
                parse_mode='Markdown'
            )

        except Exception as e:
            logger.error(f"Ошибка обработки фото: {e}")
            error_message = ("Упс, что-то пошло не так. " 
                             "Возможно, твоя еда слишком горяча для моего анализа 😏 " 
                             "Попробуй прислать фото еще раз.")
            self.bot.send_message(
                message.chat.id,
                error_message,
                reply_markup=main_menu()
            )

    def register_handlers(self):
        """Регистрация обработчиков сообщений"""
        @self.bot.message_handler(func=lambda message: message.text == "🍽️ Анализ блюда")
        def start_analysis(message):
            self.handle_start_analysis(message)

        @self.bot.message_handler(content_types=['photo'])
        def process_photo(message):
            self.handle_photo(message)
