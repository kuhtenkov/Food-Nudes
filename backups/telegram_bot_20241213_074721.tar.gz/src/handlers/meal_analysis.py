import os
import logging
from telebot import TeleBot, types
from openai import OpenAI
import base64
from utils.keyboards import main_menu

logger = logging.getLogger(__name__)

class MealAnalysisHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        try:
            self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            logger.info("OpenAI client successfully initialized")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            raise

    def encode_image(self, image_path):
        """Кодирование изображения в base64"""
        try:
            with open(image_path, "rb") as image_file:
                return base64.b64encode(image_file.read()).decode('utf-8')
        except Exception as e:
            logger.error(f"Ошибка при кодировании изображения: {e}")
            raise

    def handle_start_analysis(self, message):
        """Начало анализа блюда"""
        try:
            self.bot.send_message(
                message.chat.id,
                "Пожалуйста, отправьте фото блюда для анализа. "
                "Постарайтесь сделать фото при хорошем освещении.",
                reply_markup=types.ReplyKeyboardRemove()
            )
        except Exception as e:
            logger.error(f"Ошибка при отправке стартового сообщения: {e}")
            self.bot.send_message(
                message.chat.id,
                "Произошла ошибка. Попробуйте позже.",
                reply_markup=main_menu()
            )

    def handle_photo(self, message):
        """Обработка полученного фото"""
        try:
            # Отправляем сообщение о начале обработки
            processing_msg = self.bot.send_message(
                message.chat.id,
                "Анализирую фото... Это может занять около минуты."
            )

            # Получение информации о фото
            file_info = self.bot.get_file(message.photo[-1].file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)

            # Создаем временную директорию, если её нет
            os.makedirs("temp", exist_ok=True)
            file_path = f"temp/{message.photo[-1].file_id}.jpg"
            
            try:
                # Сохранение изображения
                with open(file_path, "wb") as file:
                    file.write(downloaded_file)

                # Кодируем изображение в base64
                base64_image = self.encode_image(file_path)

            finally:
                # Удаляем локальный файл в любом случае
                if os.path.exists(file_path):
                    os.remove(file_path)

            # Отправляем запрос в OpenAI
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": ("Ты эксперт по питанию. Проанализируй блюдо и предоставь:\n"
                                  "1. Определение основных ингредиентов\n"
                                  "2. Примерную калорийность на порцию\n"
                                  "3. Пищевую ценность (белки, жиры, углеводы)\n"
                                  "4. Рекомендации по употреблению")
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Детально опиши и проанализируй это блюдо"},
                            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                        ]
                    }
                ]
            )

            # Удаляем сообщение о обработке
            self.bot.delete_message(message.chat.id, processing_msg.message_id)

            # Отправляем результат
            self.bot.send_message(
                message.chat.id,
                f"🍽 Анализ блюда:\n\n{response.choices[0].message.content}",
                reply_markup=main_menu(),
                parse_mode='Markdown'
            )

        except Exception as e:
            logger.error(f"Ошибка обработки фото: {e}")
            error_message = ("Извините, произошла ошибка при анализе фото. "
                           "Убедитесь, что фото четкое и попробуйте снова.")
            self.bot.send_message(
                message.chat.id,
                error_message,
                reply_markup=main_menu()
            )

    def register_handlers(self):
        """Регистрация обработчиков сообщений"""
        @self.bot.message_handler(func=lambda message: message.text == "🍽️ Анализ блюда")
        def start_analysis(message):
            self.handle_start_analysis(message)

        @self.bot.message_handler(content_types=['photo'])
        def process_photo(message):
            self.handle_photo(message)
