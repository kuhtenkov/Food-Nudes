import sqlite3
import logging

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path="/root/telegram_bot/src/user_profiles.db"):
        self.connection = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.connection.cursor()
        self.init_db()

    def init_db(self):
        """Инициализация базы данных."""
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            age INTEGER,
            height REAL,
            weight REAL,
            goal TEXT,
            daily_calories INTEGER,
            activity_level TEXT DEFAULT 'Не указан',
            free_generations INTEGER DEFAULT 0,
            total_generations INTEGER DEFAULT 0
        )
        """)
        self.connection.commit()

    def get_user_profile(self, user_id):
        """Получение профиля пользователя."""
        try:
            query = """
            SELECT age, height, weight, goal, daily_calories, activity_level
            FROM users
            WHERE user_id = ?
            """
            self.cursor.execute(query, (user_id,))
            return self.cursor.fetchone()
        except sqlite3.Error as e:
            logger.error(f"Ошибка получения профиля пользователя: {e}")
            return None

    def update_user_profile(self, user_id, field, value):
        """Обновление поля профиля пользователя."""
        try:
            query = f"UPDATE users SET {field} = ? WHERE user_id = ?"
            self.cursor.execute(query, (value, user_id))
            self.connection.commit()
            logger.info(f"Обновлено поле {field} для пользователя {user_id}")
        except sqlite3.Error as e:
            logger.error(f"Ошибка обновления профиля пользователя: {e}")

    def ensure_user_exists(self, user_id):
        """Проверяет, существует ли пользователь, и добавляет его, если нет."""
        try:
            query = "SELECT 1 FROM users WHERE user_id = ?"
            self.cursor.execute(query, (user_id,))
            if not self.cursor.fetchone():
                query = """
                INSERT INTO users (user_id, age, height, weight, goal, daily_calories, activity_level)
                VALUES (?, NULL, NULL, NULL, NULL, NULL, 'Не указан')
                """
                self.cursor.execute(query, (user_id,))
                self.connection.commit()
                logger.info(f"Создан профиль для нового пользователя {user_id}")
        except sqlite3.Error as e:
            logger.error(f"Ошибка создания профиля пользователя: {e}")

    def check_user_generations(self, user_id):
        """Проверка количества бесплатных и общих генераций пользователя."""
        try:
            query = """
            SELECT free_generations, total_generations
            FROM users
            WHERE user_id = ?
            """
            self.cursor.execute(query, (user_id,))
            result = self.cursor.fetchone()
            if result:
                return result  # Возвращаем (free_generations, total_generations)
            else:
                # Если пользователь не найден, возвращаем значения по умолчанию
                return 0, 0
        except sqlite3.Error as e:
            logger.error(f"Ошибка проверки генераций пользователя: {e}")
            return 0, 0

